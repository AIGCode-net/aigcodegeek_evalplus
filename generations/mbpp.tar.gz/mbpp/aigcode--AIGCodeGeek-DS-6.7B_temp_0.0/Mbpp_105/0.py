"""
Write a python function to count true booleans in the given list.
assert count([True,False,True]) == 2
"""

def count(lst):
    return lst.count(True)
