"""
Write a function to return two words from a list of words starting with letter 'p'.
assert start_withp(["Python PHP", "Java JavaScript", "c c++"])==('Python', 'PHP')
"""


def start_withp(words):
    for word in words:
        if word.startswith('p'):
            return tuple(word.split())
    return None
