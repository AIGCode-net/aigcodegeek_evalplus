"""
Write a function to sum all amicable numbers from 1 to a specified number.
assert amicable_numbers_sum(999)==504
"""


def amicable_numbers_sum(n):
    def sum_divisors(num):
        result = 0
        i = 1
        while i * i <= num:
            if num % i == 0:
                result += i
                if i * i != num:
                    result += num // i
            i += 1
        return result - num

    def is_amicable(num):
        a = sum_divisors(num)
        b = sum_divisors(a)
        return num != a and num == b

    return sum(num for num in range(1, n + 1) if is_amicable(num))
