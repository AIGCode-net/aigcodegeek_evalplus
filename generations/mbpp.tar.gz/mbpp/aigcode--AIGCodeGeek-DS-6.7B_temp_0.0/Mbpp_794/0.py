"""
Write a function that matches a string that has an 'a' followed by anything, ending in 'b'.
assert text_starta_endb("aabbbb")
"""


import re

def text_starta_endb(text):
    pattern = r'^a.*b$'
    if re.match(pattern, text):
        return True
    else:
        return False
