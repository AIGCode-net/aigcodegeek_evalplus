"""
Write a python function to find the sum of xor of all pairs of numbers in the given list.
assert pair_xor_Sum([5,9,7,6],4) == 47
"""


def pair_xor_Sum(lst, n):
    result = 0
    for i in range(n):
        for j in range(i + 1, n):
            result += lst[i] ^ lst[j]
    return result

# Test the function