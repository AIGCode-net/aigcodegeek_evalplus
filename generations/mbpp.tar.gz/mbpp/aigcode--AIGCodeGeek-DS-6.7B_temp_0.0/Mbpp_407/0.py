"""
Write a function to create the next bigger number by rearranging the digits of a given number.
assert rearrange_bigger(12)==21
"""

def rearrange_bigger(n):
    digits = [int(d) for d in str(n)]
    for i in range(len(digits)-2, -1, -1):
        if digits[i] < digits[i+1]:
            break
    else:
        return n
    for j in range(len(digits)-1, i, -1):
        if digits[j] > digits[i]:
            break
    digits[i], digits[j] = digits[j], digits[i]
    digits[i+1:] = reversed(digits[i+1:])
    return int(''.join(map(str, digits)))