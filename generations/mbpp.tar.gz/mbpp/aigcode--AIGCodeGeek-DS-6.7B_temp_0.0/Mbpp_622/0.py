"""
Write a function to find the median of two sorted lists of same size.
assert get_median([1, 12, 15, 26, 38], [2, 13, 17, 30, 45], 5) == 16.0
"""


def get_median(list1, list2, n):
    merged_list = sorted(list1 + list2)
    if n % 2 == 0:
        median = (merged_list[n//2] + merged_list[n//2 - 1]) / 2
    else:
        median = merged_list[n//2]
    return median
