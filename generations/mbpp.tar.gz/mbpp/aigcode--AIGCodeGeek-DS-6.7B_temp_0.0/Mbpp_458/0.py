"""
Write a function to find the area of a rectangle.
assert rectangle_area(10,20)==200
"""

def rectangle_area(length, width):
    return length * width
