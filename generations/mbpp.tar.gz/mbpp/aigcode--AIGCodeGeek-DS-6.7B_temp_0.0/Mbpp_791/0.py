"""
Write a function to remove tuples from the given tuple.
assert remove_nested((1, 5, 7, (4, 6), 10)) == (1, 5, 7, 10)
"""


def remove_nested(t):
    result = []
    for i in t:
        if isinstance(i, tuple):
            result.extend(remove_nested(i))
        else:
            result.append(i)
    return tuple(result)

# Test the function