"""
Write a python function to find sum of products of all possible sublists of a given list. https://www.geeksforgeeks.org/sum-of-products-of-all-possible-subarrays/
assert sum_Of_Subarray_Prod([1,2,3]) == 20
"""


def sum_Of_Subarray_Prod(arr):
    n = len(arr)
    sum = 0
    for i in range(n):
        product = 1
        for j in range(i, n):
            product *= arr[j]
            sum += product
    return sum
