"""
Write a python function to find the first repeated character in a given string.
assert first_repeated_char("abcabc") == "a"
"""


def first_repeated_char(s):
    char_count = {}
    for char in s:
        if char in char_count:
            return char
        else:
            char_count[char] = 1
    return None

# Test the function