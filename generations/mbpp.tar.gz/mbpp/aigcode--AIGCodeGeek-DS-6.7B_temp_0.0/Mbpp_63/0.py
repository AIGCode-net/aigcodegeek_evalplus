"""
Write a function to find the maximum difference between available pairs in the given tuple list.
assert max_difference([(3, 5), (1, 7), (10, 3), (1, 2)]) == 7
"""


def max_difference(tuples):
    max_diff = 0
    for t in tuples:
        diff = abs(t[0] - t[1])
        if diff > max_diff:
            max_diff = diff
    return max_diff