"""
Write a python function to find the highest power of 2 that is less than or equal to n.
assert highest_Power_of_2(10) == 8
"""


def highest_Power_of_2(n):
    i = 1
    while i <= n:
        i = i * 2
    return i // 2
