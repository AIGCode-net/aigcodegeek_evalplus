"""
Write a python function to count minimum number of swaps required to convert one binary number represented as a string to another.
assert min_Swaps("1101","1110") == 1
"""


def min_Swaps(s1, s2):
    # Count the number of differing bits
    diff_bits = sum(c1 != c2 for c1, c2 in zip(s1, s2))

    # If the number of differing bits is odd, it's impossible to convert
    if diff_bits % 2 != 0:
        return -1

    # Count the number of swaps needed to make the differing bits match
    swaps = diff_bits // 2

    return swaps