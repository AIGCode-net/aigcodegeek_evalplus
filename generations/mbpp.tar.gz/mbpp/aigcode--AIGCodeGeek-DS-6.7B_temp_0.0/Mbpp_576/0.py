"""
Write a python function to check whether a list is sublist of another or not.
assert is_Sub_Array([1,4,3,5],[1,2]) == False
"""

def is_Sub_Array(arr, sub):
    return set(sub).issubset(set(arr))

# Test the function