"""
Write a python function to set the left most unset bit.
assert set_left_most_unset_bit(10) == 14
"""


def set_left_most_unset_bit(n):
    if n == 0:
        return 1
    if n % 2 == 0:
        return n + 1
    else:
        return n + 2
