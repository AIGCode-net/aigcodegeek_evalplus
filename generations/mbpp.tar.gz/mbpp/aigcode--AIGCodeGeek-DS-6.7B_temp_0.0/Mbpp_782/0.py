"""
Write a python function to find the sum of all odd length subarrays. https://www.geeksforgeeks.org/sum-of-all-odd-length-subarrays/
assert odd_length_sum([1,2,4]) == 14
"""


def odd_length_sum(arr):
    n = len(arr)
    total_sum = 0
    for i in range(n):
        total_sum += ((i+1)*(n-i)+1)//2 * arr[i]
    return total_sum
