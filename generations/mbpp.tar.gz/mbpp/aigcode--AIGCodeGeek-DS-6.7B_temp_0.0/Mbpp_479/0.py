"""
Write a python function to find the first digit of a given number.
assert first_Digit(123) == 1
"""

def first_Digit(n):
    while n >= 10:
        n //= 10
    return n