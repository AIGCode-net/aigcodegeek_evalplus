"""
Write a python function to toggle bits of the number except the first and the last bit. https://www.geeksforgeeks.org/toggle-bits-number-expect-first-last-bits/
assert toggle_middle_bits(9) == 15
"""


def toggle_middle_bits(n):
    # Count the number of bits in n
    count = 0
    x = n
    while x > 0:
        x >>= 1
        count += 1

    # Toggle bits from index 1 to count-2
    mask = (1 << (count - 2)) - 1
    return n ^ mask

# Test the function