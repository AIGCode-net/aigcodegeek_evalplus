"""
Write a function to sort a list of elements.
assert pancake_sort([15, 79, 25, 38, 69]) == [15, 25, 38, 69, 79]
"""


def pancake_sort(arr):
    # Flip the largest number to the beginning
    for i in range(len(arr), 0, -1):
        max_idx = arr.index(max(arr[:i]))
        arr[:max_idx+1] = arr[:max_idx+1][::-1]
        arr[:i] = arr[:i][::-1]
    return arr