"""
Write a function to remove odd characters in a string.
assert remove_odd("python")==("yhn")
"""


def remove_odd(s):
    return s[::2]
