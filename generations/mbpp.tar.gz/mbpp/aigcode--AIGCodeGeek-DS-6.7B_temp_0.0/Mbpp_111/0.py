"""
Write a function to find the common elements in given nested lists.
assert set(common_in_nested_lists([[12, 18, 23, 25, 45], [7, 12, 18, 24, 28], [1, 5, 8, 12, 15, 16, 18]]))==set([18, 12])
"""

def common_in_nested_lists(nested_list):
    if not nested_list:
        return []
    common_elements = set(nested_list[0])
    for lst in nested_list[1:]:
        common_elements = common_elements.intersection(set(lst))
    return list(common_elements)