"""
Write a function to find perfect squares between two given numbers.
assert perfect_squares(1,30)==[1, 4, 9, 16, 25]
"""


def perfect_squares(start, end):
    result = []
    for i in range(start, end+1):
        if (i**0.5).is_integer():
            result.append(i)
    return result
