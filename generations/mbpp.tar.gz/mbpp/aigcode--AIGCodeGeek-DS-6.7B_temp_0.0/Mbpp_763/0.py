"""
Write a python function to find the minimum difference between any two elements in a given array. https://www.geeksforgeeks.org/find-minimum-difference-pair/
assert find_min_diff((1,5,3,19,18,25),6) == 1
"""


def find_min_diff(arr, n):
    # Initialize the minimum difference
    min_diff = float('inf')

    # Sort the array in ascending order
    arr.sort()

    # Find the minimum difference by comparing adjacent elements
    for i in range(1, n):
        diff = arr[i] - arr[i-1]
        min_diff = min(min_diff, diff)

    return min_diff

# Test the function