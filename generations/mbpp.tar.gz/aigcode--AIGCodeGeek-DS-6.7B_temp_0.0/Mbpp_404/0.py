"""
Write a python function to find the minimum of two numbers.
assert minimum(1,2) == 1
"""

def minimum(a, b):
    if a < b:
        return a
    else:
        return b