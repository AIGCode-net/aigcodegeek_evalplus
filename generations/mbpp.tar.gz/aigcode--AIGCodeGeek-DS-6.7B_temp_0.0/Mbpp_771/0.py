"""
Write a function to check if the given expression is balanced or not. https://www.geeksforgeeks.org/check-for-balanced-parentheses-in-an-expression/
assert check_expression("{()}[{}]") == True
"""


def check_expression(expression):
    stack = []
    opening = ['(', '{', '[']
    closing = [')', '}', ']']
    for char in expression:
        if char in opening:
            stack.append(char)
        elif char in closing:
            if not stack:
                return False
            elif opening.index(stack.pop()) != closing.index(char):
                return False
    return not stack
