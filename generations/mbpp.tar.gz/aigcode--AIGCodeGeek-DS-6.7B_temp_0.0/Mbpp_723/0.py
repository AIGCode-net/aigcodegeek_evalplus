"""
The input is defined as two lists of the same length. Write a function to count indices where the lists have the same values.
assert count_same_pair([1, 2, 3, 4, 5, 6, 7, 8],[2, 2, 3, 1, 2, 6, 7, 9])==4
"""


def count_same_pair(list1, list2):
    return sum(1 for a, b in zip(list1, list2) if a == b)
