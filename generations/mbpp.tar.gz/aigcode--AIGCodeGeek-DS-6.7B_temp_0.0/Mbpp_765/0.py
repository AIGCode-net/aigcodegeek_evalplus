"""
Write a function to find nth polite number. geeksforgeeks.org/n-th-polite-number/
assert is_polite(7) == 11
"""


def is_polite(n):
    def count_set_bits(n):
        count = 0
        while n:
            n = n & (n - 1)
            count += 1
        return count

    def is_power_of_2(n):
        return n and (not (n & (n - 1)))

    def is_polite_util(n):
        if n <= 0:
            return False
        if is_power_of_2(n):
            return True
        if n & (n - 1) == 0:
            return False
        return is_polite_util(n - count_set_bits(n))

    polite_num = 1
    count = 1
    while count < n:
        polite_num += 1
        if is_polite_util(polite_num):
            count += 1
    return polite_num
