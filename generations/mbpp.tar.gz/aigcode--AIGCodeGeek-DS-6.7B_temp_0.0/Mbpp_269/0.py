"""
Write a function to find the ascii value of a character.
assert ascii_value('A')==65
"""

def ascii_value(char):
    return ord(char)