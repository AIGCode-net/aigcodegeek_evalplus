"""
Write a python function to find the element that appears only once in a sorted array.
assert search([1,1,2,2,3]) == 3
"""

def search(arr):
    for i in range(0, len(arr), 2):
        if i == len(arr) - 1 or arr[i] != arr[i+1]:
            return arr[i]

# Test the function