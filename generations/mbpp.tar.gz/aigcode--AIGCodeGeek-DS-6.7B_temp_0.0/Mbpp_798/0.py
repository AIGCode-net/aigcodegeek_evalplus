"""
Write a python function to find the sum of an array.
assert _sum([1, 2, 3]) == 6
"""

def _sum(arr):
    return sum(arr)
