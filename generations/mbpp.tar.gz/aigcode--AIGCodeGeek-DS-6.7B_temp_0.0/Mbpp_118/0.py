"""
Write a function to convert a string to a list of strings split on the space character.
assert string_to_list("python programming")==['python','programming']
"""

def string_to_list(s):
    return s.split()

# Test the function