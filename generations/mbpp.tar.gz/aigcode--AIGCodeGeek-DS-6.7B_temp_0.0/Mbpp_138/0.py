"""
Write a python function to check whether the given number can be represented as sum of non-zero powers of 2 or not.
assert is_Sum_Of_Powers_Of_Two(10) == True
"""


def is_Sum_Of_Powers_Of_Two(n):
    if n < 1:
        return False
    while n != 0:
        if n & 1:
            n = n >> 1
        else:
            return False
    return True
