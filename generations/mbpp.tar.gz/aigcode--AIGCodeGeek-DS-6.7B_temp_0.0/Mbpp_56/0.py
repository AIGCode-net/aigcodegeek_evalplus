"""
Write a python function to check if a given number is one less than twice its reverse.
assert check(70) == False
"""


def check(num):
    reverse_num = int(str(num)[::-1])
    if num == 2 * reverse_num - 1:
        return True
    else:
        return False
