"""
Write a function to check if each element of second tuple is smaller than its corresponding element in the first tuple.
assert check_smaller((1, 2, 3), (2, 3, 4)) == False
"""


def check_smaller(t1, t2):
    for i in range(len(t1)):
        if t1[i] >= t2[i]:
            return False
    return True