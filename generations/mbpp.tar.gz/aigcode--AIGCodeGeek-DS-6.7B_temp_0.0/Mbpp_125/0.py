"""
Write a function to find the maximum difference between the number of 0s and number of 1s in any sub-string of the given binary string.
assert find_length("11000010001") == 6
"""


def find_length(s):
    max_diff = 0
    count = 0
    for i in range(len(s)):
        if s[i] == '0':
            count += 1
        else:
            count -= 1
        if count < 0:
            count = 0
        max_diff = max(max_diff, count)
    return max_diff
