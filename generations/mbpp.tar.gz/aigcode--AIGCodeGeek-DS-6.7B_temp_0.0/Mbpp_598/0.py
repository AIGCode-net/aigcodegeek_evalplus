"""
Write a function to check whether the given number is armstrong or not.
assert armstrong_number(153)==True
"""

def armstrong_number(num):
    # Convert the number to string to get the number of digits
    num_str = str(num)
    num_digits = len(num_str)

    # Calculate the sum of the digits raised to the power of the number of digits
    sum_of_digits = sum(int(digit)**num_digits for digit in num_str)

    # Check if the sum is equal to the original number
    if sum_of_digits == num:
        return True
    else:
        return False

# Test the function