"""
Write a function to check whether it follows the sequence given in the patterns array.
assert is_samepatterns(["red","green","green"], ["a", "b", "b"])==True
"""


def is_samepatterns(arr1, arr2):
    return arr1 == arr2
