"""
Write a function to compute the sum of digits of each number of a given list.
assert sum_of_digits([10,2,56])==14
"""

def sum_of_digits(lst):
    result = 0
    for num in lst:
        for digit in str(num):
            result += int(digit)
    return result