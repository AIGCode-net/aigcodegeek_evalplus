"""
Write a function to find the largest sum of a contiguous array in the modified array which is formed by repeating the given array k times.
assert max_sub_array_sum_repeated([10, 20, -30, -1], 4, 3) == 30
"""


def max_sub_array_sum_repeated(arr, n, k):
    def kadane(arr):
        max_so_far = arr[0]
        max_ending_here = arr[0]
        for i in range(1, len(arr)):
            max_ending_here = max(arr[i], max_ending_here + arr[i])
            max_so_far = max(max_so_far, max_ending_here)
        return max_so_far

    total_sum = sum(arr)
    max_sum = kadane(arr)
    if total_sum < 0:
        return max_sum
    else:
        return max(max_sum, total_sum * k)
