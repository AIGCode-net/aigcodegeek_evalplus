"""
Write a python function to check whether the given number can be represented as the difference of two squares or not.
assert dif_Square(5) == True
"""


def dif_Square(n):
    for i in range(0, int(n**0.5) + 1):
        j = (n - i*i)**0.5
        if j.is_integer():
            return True
    return False
