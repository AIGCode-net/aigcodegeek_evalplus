"""
Write a python function to find whether a number is divisible by 11.
assert is_Diff (12345) == False
"""


def is_Diff(num):
    return num % 11 == 0
