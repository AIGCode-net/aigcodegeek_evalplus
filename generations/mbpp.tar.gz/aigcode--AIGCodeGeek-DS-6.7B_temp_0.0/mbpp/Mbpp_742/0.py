"""
Write a function to caluclate the area of a tetrahedron.
assert area_tetrahedron(3)==15.588457268119894
"""

import math

def area_tetrahedron(side_length):
    # Calculate the area of a tetrahedron using the formula: A = sqrt(3) * side_length^2
    area = math.sqrt(3) * side_length ** 2
    return area

# Test the function