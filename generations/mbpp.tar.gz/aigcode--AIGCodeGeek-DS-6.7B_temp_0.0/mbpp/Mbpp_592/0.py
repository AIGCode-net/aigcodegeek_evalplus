"""
Write a python function to find the sum of the product of consecutive binomial co-efficients.
assert sum_Of_product(3) == 15
"""


def sum_Of_product(n):
    def binomial_coefficient(n, k):
        if k > n:
            return 0
        if k == 0 or k == n:
            return 1
        return binomial_coefficient(n-1, k-1) + binomial_coefficient(n-1, k)

    product = 1
    for i in range(1, n):
        product *= binomial_coefficient(n, i)

    return product

# Test the function