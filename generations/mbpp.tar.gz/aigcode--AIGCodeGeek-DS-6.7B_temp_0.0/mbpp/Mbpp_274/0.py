"""
Write a python function that takes in a positive integer n and finds the sum of even index binomial coefficients.
assert even_binomial_Coeff_Sum(4) == 8
"""


def even_binomial_Coeff_Sum(n):
    def binomial_coefficient(n, k):
        res = 1
        for i in range(1, k+1):
            res = res * (n-i+1) // i
        return res

    sum = 0
    for i in range(0, n+1, 2):
        sum += binomial_coefficient(n, i)
    return sum
