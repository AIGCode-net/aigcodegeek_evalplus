"""
Write a function to count bidirectional tuple pairs.
assert count_bidirectional([(5, 6), (1, 2), (6, 5), (9, 1), (6, 5), (2, 1)] ) == 3
"""


def count_bidirectional(tuples):
    count = 0
    for i in range(len(tuples)):
        for j in range(i+1, len(tuples)):
            if tuples[i] == tuples[j] or tuples[i][::-1] == tuples[j]:
                count += 1
    return count