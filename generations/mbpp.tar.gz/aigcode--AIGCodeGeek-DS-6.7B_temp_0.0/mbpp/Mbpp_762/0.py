"""
Write a function to check whether the given month number contains 30 days or not. Months are given as number from 1 to 12.
assert check_monthnumber_number(6)==True
"""


def check_monthnumber_number(month_number):
    # Months with 30 days: April (4), June (6), September (9), November (11)
    if month_number in [4, 6, 9, 11]:
        return True
    else:
        return False

# Test the function