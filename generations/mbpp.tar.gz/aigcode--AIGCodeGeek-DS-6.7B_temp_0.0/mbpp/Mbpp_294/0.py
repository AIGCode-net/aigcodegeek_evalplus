"""
Write a function to find the maximum value in a given heterogeneous list.
assert max_val(['Python', 3, 2, 4, 5, 'version'])==5
"""

def max_val(lst):
    max_val = None
    for item in lst:
        if isinstance(item, int) or isinstance(item, float):
            if max_val is None or item > max_val:
                max_val = item
    return max_val
