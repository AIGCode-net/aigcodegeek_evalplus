"""
Write a python function to find the next perfect square greater than a given number.
assert next_Perfect_Square(35) == 36
"""


import math

def next_Perfect_Square(n):
    # Find the square root of the given number
    sqrt_n = math.sqrt(n)

    # Find the next integer greater than the square root
    next_int = math.ceil(sqrt_n)

    # Return the square of the next integer
    return next_int * next_int

# Test the function