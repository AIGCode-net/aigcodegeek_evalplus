"""
Write a python function to find the area of the largest triangle that can be inscribed in a semicircle with a given radius.
assert triangle_area(-1) == None
"""


def triangle_area(radius):
    if radius < 0:
        return None
    else:
        return 0.5 * radius * radius
