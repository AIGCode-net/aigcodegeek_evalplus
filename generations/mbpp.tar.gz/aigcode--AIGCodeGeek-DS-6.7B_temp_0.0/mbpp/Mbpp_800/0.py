"""
Write a function to remove all whitespaces from a string.
assert remove_all_spaces('python  program')==('pythonprogram')
"""

def remove_all_spaces(s):
    return s.replace(" ", "")

# Test the function