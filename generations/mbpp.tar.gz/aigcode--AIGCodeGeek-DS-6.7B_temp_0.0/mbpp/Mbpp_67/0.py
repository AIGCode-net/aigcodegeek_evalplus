"""
Write a function to find the number of ways to partition a set of Bell numbers.
assert bell_number(2)==2
"""
