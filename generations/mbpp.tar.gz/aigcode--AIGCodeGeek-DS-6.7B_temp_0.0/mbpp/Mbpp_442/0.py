"""
Write a function to find the ration of positive numbers in an array of integers.
assert positive_count([0, 1, 2, -1, -5, 6, 0, -3, -2, 3, 4, 6, 8])==0.54
"""

def positive_count(arr):
    pos_count = 0
    total_count = 0
    for num in arr:
        if num > 0:
            pos_count += 1
        total_count += 1
    return pos_count / total_count