"""
Write a python function to check whether the given number is even or not.
assert is_Even(1) == False
"""

def is_Even(num):
    return num % 2 == 0