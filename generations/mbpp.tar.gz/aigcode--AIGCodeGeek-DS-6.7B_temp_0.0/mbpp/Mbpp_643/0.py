"""
Write a function that checks if a strings contains 'z', except at the start and end of the word.
assert text_match_wordz_middle("pythonzabc.")==True
"""


def text_match_wordz_middle(text):
    words = text.split()
    for word in words:
        if len(word) > 2 and 'z' in word[1:-1]:
            return True
    return False
