"""
Write a python function to find the volume of a triangular prism.
assert find_Volume(10,8,6) == 240
"""

def find_Volume(base, height, prism_height):
    # Calculate the area of the base
    base_area = 0.5 * base * height
    # Calculate the volume of the prism
    volume = base_area * prism_height
    return volume

# Test the function