"""
Write a function to find kth element from the given two sorted arrays.
assert find_kth([2, 3, 6, 7, 9], [1, 4, 8, 10], 5) == 6
"""


def find_kth(arr1, arr2, k):
    i, j = 0, 0
    while i + j < k:
        if i == len(arr1):
            return arr2[j + k - i - 1]
        if j == len(arr2):
            return arr1[i + k - j - 1]
        if arr1[i] < arr2[j]:
            i += 1
        else:
            j += 1
    if arr1[i] < arr2[j]:
        return arr1[i]
    else:
        return arr2[j]