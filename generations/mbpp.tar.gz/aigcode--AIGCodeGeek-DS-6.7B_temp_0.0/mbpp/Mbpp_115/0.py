"""
Write a function to check whether all dictionaries in a list are empty or not.
assert empty_dit([{},{},{}])==True
"""


def empty_dict(lst):
    for d in lst:
        if d:
            return False
    return True
