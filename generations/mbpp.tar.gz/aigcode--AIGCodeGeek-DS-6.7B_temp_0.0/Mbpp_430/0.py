"""
Write a function to find the directrix of a parabola.
assert parabola_directrix(5,3,2)==-198
"""

def parabola_directrix(a, b, c):
    return -b**2 / (4*a) - c
