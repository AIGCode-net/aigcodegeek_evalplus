"""
Write a python function to move all zeroes to the end of the given list.
assert move_zero([1,0,2,0,3,4]) == [1,2,3,4,0,0]
"""


def move_zero(lst):
    # Count the number of zeroes in the list
    zero_count = lst.count(0)
    
    # Remove all zeroes from the list
    lst = [num for num in lst if num != 0]
    
    # Append zero_count number of zeroes to the list
    lst.extend([0] * zero_count)
    
    return lst