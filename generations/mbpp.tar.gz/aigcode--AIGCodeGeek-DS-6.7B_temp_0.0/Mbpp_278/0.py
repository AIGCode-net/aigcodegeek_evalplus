"""
Write a function to find the number of elements that occurs before the tuple element in the given tuple.
assert count_first_elements((1, 5, 7, (4, 6), 10) ) == 3
"""


def count_first_elements(tup):
    count = 0
    for i in range(len(tup)):
        if isinstance(tup[i], tuple):
            break
        count += 1
    return count
