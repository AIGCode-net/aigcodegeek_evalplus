"""
Write a python function to set all even bits of a given number.
assert even_bit_set_number(10) == 10
"""


def even_bit_set_number(num):
    binary = bin(num)[2:]  # Convert number to binary
    binary = '0' + binary[1:]  # Set the first bit to 0
    for i in range(2, len(binary), 2):
        binary = binary[:i] + '1' + binary[i+1:]  # Set even bits to 1
    return int(binary, 2)  # Convert binary back to number

# Test the function