"""
Write a function to check whether a given string is a decimal number with a precision of 2.
assert is_decimal('123.11')==True
"""


def is_decimal(s):
    try:
        float(s)
        parts = s.split('.')
        if len(parts) > 2:
            return False
        if len(parts) == 2 and len(parts[1]) > 2:
            return False
        return True
    except ValueError:
        return False
