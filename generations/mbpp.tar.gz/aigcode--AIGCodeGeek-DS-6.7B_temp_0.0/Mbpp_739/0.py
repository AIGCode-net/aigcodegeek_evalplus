"""
Write a python function to find the index of smallest triangular number with n digits. https://www.geeksforgeeks.org/index-of-smallest-triangular-number-with-n-digits/
assert find_Index(2) == 4
"""


def find_Index(n):
    # Initialize the index
    index = 1

    # Loop until the triangular number has n digits
    while len(str(index * (index + 1) // 2)) < n:
        index += 1

    return index