"""
Write a function that takes in positive integers m and n and finds the number of possible sequences of length n, such that each element is a positive integer and is greater than or equal to twice the previous element but less than or equal to m.
assert get_total_number_of_sequences(10, 4) == 4
"""


def get_total_number_of_sequences(m, n):
    def helper(m, n, prev):
        if n == 0:
            return 1
        count = 0
        for i in range(prev, m+1):
            if i >= 2 * prev:
                count += helper(m, n-1, i)
        return count
    return helper(m, n, 1)