"""
Write a function to find the closest smaller number than n.
assert closest_num(11) == 10
"""

def closest_num(n):
    return n - 1