"""
Write a function to find the nth newman–shanks–williams prime number.
assert newman_prime(3) == 7
"""
