"""
Write a function to check whether a list contains the given sublist or not.
assert is_sublist([2,4,3,5,7],[3,7])==False
"""


def is_sublist(lst, sublist):
    return sublist in lst
