"""
Write a function to extract all the adjacent coordinates of the given coordinate tuple.
assert get_coordinates((3, 4)) == [[2, 3], [2, 4], [2, 5], [3, 3], [3, 4], [3, 5], [4, 3], [4, 4], [4, 5]]
"""


def get_coordinates(coordinate):
    x, y = coordinate
    adjacent_coordinates = []
    for i in range(-1, 2):
        for j in range(-1, 2):
            if i != 0 or j != 0:
                adjacent_coordinates.append([x + i, y + j])
    return adjacent_coordinates