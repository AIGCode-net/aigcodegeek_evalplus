"""
Write a function to calculate a dog's age in dog's years.
assert dog_age(12)==61
"""

def dog_age(human_age):
    if human_age <= 2:
        return human_age * 10.5
    else:
        return 21 + (human_age - 2) * 4

# Test the function