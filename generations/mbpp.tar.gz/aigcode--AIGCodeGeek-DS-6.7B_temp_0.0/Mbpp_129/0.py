"""
Write a function to calculate whether the matrix is a magic square.
assert magic_square_test([[7, 12, 1, 14], [2, 13, 8, 11], [16, 3, 10, 5], [9, 6, 15, 4]])==True
"""


def magic_square_test(matrix):
    n = len(matrix)
    magic_constant = n * (n * n + 1) // 2

    # Check rows
    for row in matrix:
        if sum(row) != magic_constant:
            return False

    # Check columns
    for j in range(n):
        col_sum = sum(matrix[i][j] for i in range(n))
        if col_sum != magic_constant:
            return False

    # Check diagonals
    diag_sum1 = sum(matrix[i][i] for i in range(n))
    diag_sum2 = sum(matrix[i][n - i - 1] for i in range(n))
    if diag_sum1 != magic_constant or diag_sum2 != magic_constant:
        return False

    return True