"""
Write a python function to find the surface area of a square pyramid with a given base edge and height.
assert surface_Area(3,4) == 33
"""


def surface_Area(base_edge, height):
    # Calculate the area of the base
    base_area = base_edge ** 2
    
    # Calculate the area of the four triangular sides
    side_area = 0.5 * base_edge * base_edge + 2 * 0.5 * base_edge * height
    
    # Calculate the total surface area
    total_area = base_area + side_area
    
    return total_area

# Test the function