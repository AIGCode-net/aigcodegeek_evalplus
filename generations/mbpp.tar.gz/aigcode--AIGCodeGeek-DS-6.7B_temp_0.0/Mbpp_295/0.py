"""
Write a function to return the sum of all divisors of a number.
assert sum_div(8)==7
"""

def sum_div(n):
    div_sum = 0
    for i in range(1, n+1):
        if n % i == 0:
            div_sum += i
    return div_sum
