"""
Write a python function to find the sum of common divisors of two given numbers.
assert sum(10,15) == 6
"""

def sum_common_divisors(a, b):
    def get_divisors(n):
        divisors = []
        for i in range(1, n+1):
            if n % i == 0:
                divisors.append(i)
        return divisors

    divisors_a = get_divisors(a)
    divisors_b = get_divisors(b)

    common_divisors = [i for i in divisors_a if i in divisors_b]
    return sum(common_divisors)
