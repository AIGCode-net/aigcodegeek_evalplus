"""
Write a function to check if the given number is woodball or not.
assert is_woodall(383) == True
"""


def is_woodall(num):
    # A number is woodall if it is a perfect power of 3
    while num % 3 == 0:
        num /= 3
    return num == 1
