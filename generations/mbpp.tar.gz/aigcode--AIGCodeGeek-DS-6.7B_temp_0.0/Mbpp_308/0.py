"""
Write a function to find the specified number of largest products from two given lists, selecting one factor from each list.
assert large_product([1, 2, 3, 4, 5, 6],[3, 6, 8, 9, 10, 6],3)==[60, 54, 50]
"""


def large_product(list1, list2, n):
    products = [i*j for i in list1 for j in list2]
    products.sort(reverse=True)
    return products[:n]