"""
Write a function to extract values between quotation marks from a string.
assert extract_values('"Python", "PHP", "Java"')==['Python', 'PHP', 'Java']
"""


def extract_values(s):
    import re
    return re.findall(r'"([^"]*)"', s)
