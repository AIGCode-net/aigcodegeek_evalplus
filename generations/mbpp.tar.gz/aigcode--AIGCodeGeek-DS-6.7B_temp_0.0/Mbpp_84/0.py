"""
Write a function to find the nth number in the newman conway sequence.
assert sequence(10) == 6
"""


def sequence(n):
    if n == 1:
        return 1
    elif n == 2:
        return 1
    else:
        seq = [1, 1]
        for i in range(2, n):
            if seq[seq[i-1]-1] == 1:
                seq.append(i+1)
            else:
                seq.append(seq[i-1] - seq[seq[i-1]-1])
        return seq[-1]
