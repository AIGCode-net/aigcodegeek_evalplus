"""
Write a function to calculate the maximum aggregate from the list of tuples.
assert max_aggregate([('Juan Whelan',90),('Sabah Colley',88),('Peter Nichols',7),('Juan Whelan',122),('Sabah Colley',84)])==('Juan Whelan', 212)
"""


def max_aggregate(lst):
    aggregate = {}
    for name, value in lst:
        if name in aggregate:
            aggregate[name] += value
        else:
            aggregate[name] = value
    max_name = max(aggregate, key=aggregate.get)
    return (max_name, aggregate[max_name])
