"""
Write a function to remove lowercase substrings from a given string.
assert remove_lowercase("PYTHon")==('PYTH')
"""


def remove_lowercase(s):
    result = ''
    for char in s:
        if char.isupper():
            result += char
    return result
