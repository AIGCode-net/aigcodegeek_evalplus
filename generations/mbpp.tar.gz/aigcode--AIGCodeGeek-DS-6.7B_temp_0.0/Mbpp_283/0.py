"""
Write a python function takes in an integer and check whether the frequency of each digit in the integer is less than or equal to the digit itself.
assert validate(1234) == True
"""


def validate(n):
    freq = [0]*10
    while n > 0:
        digit = n % 10
        n = n // 10
        freq[digit] += 1
    for i in range(10):
        if freq[i] > i:
            return False
    return True
