"""
Write a function to find the surface area of a cylinder.
assert surfacearea_cylinder(10,5)==942.45
"""


import math

def surfacearea_cylinder(radius, height):
    # Calculate the surface area of the cylinder
    surface_area = 2 * math.pi * radius * (radius + height)
    return round(surface_area, 2)

# Test the function