"""
Write a function which returns nth catalan number.
assert catalan_number(10)==16796
"""


def catalan_number(n):
    if n <= 1:
        return 1

    # Initialize the result
    res = 0

    # Use the recursive formula to calculate the nth catalan number
    for i in range(n):
        res += catalan_number(i) * catalan_number(n - i - 1)

    return res

# Test the function