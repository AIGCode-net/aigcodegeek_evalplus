"""
Write a function to put spaces between words starting with capital letters in a given string.
assert capital_words_spaces("Python") == 'Python'
"""


def capital_words_spaces(s):
    result = ''
    for i in range(len(s)):
        if i > 0 and s[i].isupper():
            result += ' ' + s[i]
        else:
            result += s[i]
    return result