"""
Write a function to find the volume of a cube given its side length.
assert volume_cube(3)==27
"""

def volume_cube(side_length):
    return side_length ** 3
