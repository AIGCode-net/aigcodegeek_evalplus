"""
Write a python function to find the minimum number of rotations (greater than 0) required to get the same string.
assert find_Rotations("aaaa") == 1
"""


def find_Rotations(s):
    n = len(s)
    temp = s + s
    for i in range(1, n + 1):
        if temp[i:i + n] == s:
            return i
    return n
