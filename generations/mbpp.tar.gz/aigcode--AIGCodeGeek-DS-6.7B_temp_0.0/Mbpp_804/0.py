"""
Write a function to check whether the product of numbers in a list is even or not.
assert is_product_even([1,2,3])
"""

def is_product_even(nums):
    product = 1
    for num in nums:
        product *= num
    return product % 2 == 0
