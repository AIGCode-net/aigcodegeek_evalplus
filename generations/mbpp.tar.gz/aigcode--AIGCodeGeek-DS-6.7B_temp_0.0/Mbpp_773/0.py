"""
Write a function to find the occurrence and position of the substrings within a string. Return None if there is no match.
assert occurance_substring('python programming, python language','python')==('python', 0, 6)
"""


def occurance_substring(s, sub):
    pos = s.find(sub)
    if pos != -1:
        return (sub, pos, pos + len(sub))
    else:
        return None