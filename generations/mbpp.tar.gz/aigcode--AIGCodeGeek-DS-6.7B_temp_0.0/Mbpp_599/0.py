"""
Write a function to find sum and average of first n natural numbers.
assert sum_average(10)==(55, 5.5)
"""

def sum_average(n):
    # Calculate the sum of first n natural numbers
    sum_n = n * (n + 1) // 2
    # Calculate the average
    avg_n = sum_n / n
    return sum_n, avg_n

# Test the function