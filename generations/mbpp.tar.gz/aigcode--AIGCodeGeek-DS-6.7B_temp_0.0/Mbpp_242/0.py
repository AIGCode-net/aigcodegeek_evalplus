"""
Write a function to count the total number of characters in a string.
assert count_charac("python programming")==18
"""

def count_charac(string):
    return len(string)
