"""
Write a python function to remove first and last occurrence of a given character from the string.
assert remove_Occ("hello","l") == "heo"
"""


def remove_Occ(string, char):
    first_index = string.find(char)
    last_index = string.rfind(char)
    if first_index != -1 and last_index != -1:
        return string[:first_index] + string[first_index+1:last_index] + string[last_index+1:]
    else:
        return string

# Test the function