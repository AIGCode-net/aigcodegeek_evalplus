"""
Write a python function to remove odd numbers from a given list.
assert remove_odd([1,2,3]) == [2]
"""

def remove_odd(nums):
    return [num for num in nums if num % 2 == 0]